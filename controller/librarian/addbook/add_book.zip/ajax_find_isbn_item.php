<?php
    include $_SERVER['DOCUMENT_ROOT'] . "/lib/include/connect.php";
    include $_SERVER['DOCUMENT_ROOT'] . "/lib/helper/calsubfield.php";

    $bib_id = $_POST['val'];

    $sql = "SELECT * FROM databib_item WHERE Bib_ID = '{$bib_id}'" ;
    $data = $conn->query($sql);
    for ($i=0; $i < mysqli_num_rows($data) ; $i++) { 
        $data_item[$i] = $data->fetch_assoc();
    }
    // print_r($data_item);
    echo JSON_ENCODE($data_item);

?>