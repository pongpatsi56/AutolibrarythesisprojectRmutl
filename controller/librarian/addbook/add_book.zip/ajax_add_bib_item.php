<?php
    include $_SERVER['DOCUMENT_ROOT'] . "/lib/include/connect.php";

    $bib_id = $_POST['val'];
    $copy = $_POST['copy'];


    $sql = "SELECT max(Barcode) as Barcode FROM databib_item ";
    $data = $conn->query($sql);
    $barcode = $data->fetch_assoc();
    $barcode = (int)$barcode['Barcode'];
    $barcode++;

    for ($i=strlen($barcode); $i < 3 ; $i++) { 
        $barcode = "0".$barcode;
    }

    $sql = "INSERT INTO databib_item(Barcode,Bib_ID,Copy) VALUES ('{$barcode}','{$bib_id}','{$copy}')";
    $conn->query($sql);

?>