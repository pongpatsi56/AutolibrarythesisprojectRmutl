    <?php

    include $_SERVER['DOCUMENT_ROOT'] . "/lib/include/connect.php";

    $id = $_POST['id'];

    $sql = "SELECT * FROM databib WHERE Field IN ('245','020','022') AND Subfield Like '%{$id}%' ";
    $data = $conn->query($sql);
    for ($i=0; $i < mysqli_num_rows($data) ; $i++) { 
        $data_book[$i] = $data->fetch_assoc();
    }

    echo json_encode($data_book);

    ?>